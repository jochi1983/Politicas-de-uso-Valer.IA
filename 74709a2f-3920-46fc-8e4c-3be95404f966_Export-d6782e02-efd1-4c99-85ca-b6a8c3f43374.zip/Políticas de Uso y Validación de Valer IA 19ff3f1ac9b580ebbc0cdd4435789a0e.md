# Políticas de Uso y Validación de Valer.IA

**1. Introducción**

Valer.IA es un tutor virtual basado en inteligencia artificial generativa

diseñado para asisitir a

**docentes universitarios en la modalidad a distanciasobre el uso de recursos tecnologicos para aulas virtuales en la plataformaMoodle 4.3 de UCASAL X**

. Su propósito es brindar apoyo en la configuración

de recursos y uso didactico de actividades propuestas por Moodle para su

aplicacion en entornos virtuales de UcasalX

El uso de Valer.IA implica la aceptación de las siguientes

**políticas de usoy validación**

, las cuales garantizan un funcionamiento seguro, responsable y

alineado con las normativas institucionales.

**2. Uso Aceptable**

Valer.IA está diseñado para asistir en tareas tecnopedagógicas/didácticas

dentro de aulas virtuales para la comunidad de aprendizaje docentes de Ucasal .

Esto incluye:

✅ Asesoramiento sobre recursos y funcionalidades de Moodle para la

plataforma de UCASAL X.

✅ Recomendaciones sobre buenas prácticas en el uso de recursos del aula

virtual en su version Moodle4.3 y Aula Home.

✅ Apoyo en la gestión de los contenidos multimediales en los cursos y

aulas de las carreras dentro de la plataforma Ucasal.

✅ Orientación sobre evaluación de los aprendizajes, instrumentos y

recursos para la modalidad on line

✅ Orientación sobre marcos institucionales de UCASAL X relacionadas con la

implementación de tecnología para la supervisión de exámenes y modo home

**3. Uso No Permitido**

El sistema

**no debe**

ser utilizado para:

❌ Solicitar o divulgar información personal, confidencial o sensible de

docentes, estudiantes o terceros.

❌ Generar, compartir o solicitar contenido que infrinja normativas

institucionales, como fraude académico o plagio.

❌ Utilizar lenguaje ofensivo, discriminatorio o que promueva el odio o la

violencia.

❌ Intentar manipular, hackear o vulnerar la seguridad del sistema.

**4. Calidad y Veracidad de la Información**

- Valer.IA busca proporcionar

información precisa y útil, pero

**sus respuestas no deben considerarse     como asesoramiento oficial**

.

- Siempre se recomienda

verificar la información con fuentes oficiales de UCASAL X, especialmente

en temas administrativos y normativos.

- Si una respuesta parece

incorrecta o desactualizada, los usuarios pueden reportarlo para su

revisión y mejora.

**5. Privacidad y Seguridad**

- Valer.IA **no almacena ni**

**comparte información personal de los usuarios**

fuera de lo necesario

para su funcionamiento.

- Todas las interacciones se

monitorean con el objetivo de mejorar el servicio y detectar posibles usos

indebidos.

- El sistema está protegido

contra intentos de explotación, inyecciones de código y otras

vulnerabilidades de seguridad.

**6. Mejoras y Actualizaciones**

- Valer.IA se encuentra en

constante evolución para mejorar su precisión y funcionalidad.

- Las políticas de uso pueden

actualizarse según las necesidades de la comunidad docente y las

regulaciones de UCASAL X.

- Los docentes pueden enviar

sugerencias o reportes a través de los canales habilitados.

**7. Contacto y Soporte**

Si tienes dudas sobre el funcionamiento de Valer.IA o necesitas asistencia adicional,

puedes comunicarte con el equipo de soporte de la Dirección de Diseño y

Desarrollo Instruccional de UCASAL X a través de direccionddi@ucasal.edu.ar .